const constants = {
    SERVER_ERROR: 'Some error occurred',
};

module.exports = constants;
