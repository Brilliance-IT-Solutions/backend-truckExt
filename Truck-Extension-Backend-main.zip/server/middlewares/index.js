const errorMiddleware = require('./errorMiddleware');
const authenticate = require('./authenticate');

module.exports = {
    errorMiddleware,
    authenticate
}